<head><meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title> D-FORUM || RGUKT || </title>
		<link href="include/logo.png" rel="shortcut icon" type="image/x-icon" />
        <link href="css/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/modern.min.css" rel="stylesheet" type="text/css"/>
		<style>
			.det{min-width:300px;max-height:110px;border:0px solid green;margin:-100px  0 0 80%;float:left;padding-top:10px;}
			.det>img{float:right;margin:-56px 0 0 0;width:100px;height:95px;padding:0 0 5px 0;}
			.cont1{width:90%;border:1px solid black;position:relative;float:left;margin:20px 5% 30px 5%;padding:10px 10px 0 20px ;font-size:16px;color:rgba(0,40,20,0.7);line-height:2;} 
			img{float:left;}
			i{color:green;}i::first-letter{text-transform:lowercase;}{color:green;}y{color:red}
			.fields{font-size:15px;line-height:2;}
			.valu{float:left;text-align:left;color:blue;padding:10px;margin:30px 0 0 80px;}
			.inp{font-size:15px;text-align:left;padding-left:10px;text-decoration:underline;color:teal;} 
			.postbox{width:100%;margin:10px 0 0 0%;border:1px solid gray;padding:10px;min-height:68px;line-height:1.3;letter-spacing:1.2px;}
			.replybox{width:90%;margin:10px 0 0 0%;border:1px solid gray;padding:10px;min-height:68px;line-height:1.3;margin:1px 0 0 97px;}
			.head{font-size:14px;color:rgba(0,0,200,0.7);}
			.date{text-align:right;float:right;font-size:13px;color:red;margin-top:-1%;}
			.post{font-size:19px;}
			textarea{min-width:80%; padding:3px 0 0 10px;line-height:1.4;min-height:100px;}
			#replytext{min-width:100%; padding:3px 0 0 10px;line-height:1.4;min-height:10px;} 
		</style>
    </head>
    <body class=" page-horizontal-bar compact-menu slimscroll" >

        
        <main class="page-content content-wrap">
                <div class="navbar navbar-inner container">
                    <div class="logo-box" style="width:80%;">
						<img class="hidden-xs hidden-sm" src="include/logo.png" width="60" alt="" style="position:absolute;top:14%; left:0% " />
                        <a href="#" class="logo-text text-center"style="margin-left:2%;">
							<span class="header0">RAJIV GSNDHI UNIVERSITY OF KNOELEDGE TECHNOLIGIES</span><br>
							<span class="subtitle"style="margin-left:17%;">Catering to the EDUCATIONAL needs of gifed RURAL YOUTH</span> <br>
							<span class="location">######################################################## </span>
						</a>
                    </div><!-- Logo Box -->
					<div class="det" >
						<?php if($_SESSION) {
							include("include/connection.php");
							$qu1=mysql_query("select * from users where username='$_SESSION[id]'");
							$num1 = mysql_num_rows($qu1);
								if($num1!='0'){ 
									while($row1 = mysql_fetch_assoc($qu1)){ 
										$id1 = $row1['username'];  $name1=$row1['stu_name']; $class1=$row1['country']; $img1=$row1['username'].".jpg";    }
										echo"Name : $name1</br>" ;
												echo"ID : $id1</br>" ;
												echo"Branch : $class1</br>" ;
												echo"<a href='logout.php' class='btn btn-primary'> Logout</a>" ;
												echo"<img id='propicold' style='width:80px;min-heigh:190px;padding:0;' src='./stu_imgs/$img1' > ";
										}
							}else{ ?>
								<form id="form_id" method="post" name="myform" class="form-signin">
									<label style="min-width:80px;">User Name </label>
									<input type="text" name="username" id="username"data-toggle="tooltip" data-placement="top" title="Username" />
									<label  style="min-width:80px;">Password </label>
									<input type="password" name="password" id="password"/>
									<input type="button" value="Login" id="submit" onclick="validatestu()" class="btn btn-primary"/>
									<input type="reset" value="Reset" class="btn btn-primary"/>
								</form> 	<?php }	?>
					</div>
            </div>