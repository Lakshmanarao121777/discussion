<?php 




//  /*;;*/**************************************************************/*;;*/
//  /*;;*/				Database Details 								/*;;*/
//  /*;;*/			  K.Lakshmanarao ,R121777,T-4(E.C.E.)				/*;;*/
//  /*;;*/**************************************************************/*;;*/
    /*;;*/																/*;;*/
    /*;;*/  $servername     = "localhost";	       						/*;;*/
    /*;;*/  $usernamephp   = "root";									/*;;*/
    /*;;*/  $passwordphp  = "HubservRKV";			 					/*;;*/
    /*;;*/  $Database_Databse = "dforum";	        		       			/*;;*/
    /*;;*/																/*;;*/
//  /*;;*/==============================================================/*;;*/
  


$Database="$Database_Databse";
//$connt = mysqli_connect($servername, $username, $password, $Database);
// Check connection
//if (!$connt) {
//    die("Connection failed: " . mysqli_connect_error());
// }
	mysql_connect("$servername","$usernamephp","$passwordphp")or die("problem with connection.");
	mysql_select_db("$Database");
	/*try{
	$conn=new PDO("mysql:host=$servername;dbname=$Database",$usernamephp,$passwordphp);
	$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	//echo"Sucessfull";
	
	}
	catch(PDOException $e){
	echo"failed</br>".$e->getMessage();
	}*/


?>
