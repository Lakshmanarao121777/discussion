<?php session_start();
if(isset($_POST['posttext']))
   { 
   		include("include/connection.php");
                $post=mysql_real_escape_string($_POST['posttext']);
                $post = preg_replace('#[^a-z0-9/~!@$%^)(=[]/?><,._ +/*/\/]#i','', $post);
                $post = str_replace("<", "&lt;", $post);
                $post = str_replace(">", "&gt;", $post);
                $id=mysql_real_escape_string($_POST['id']);
                $name=mysql_real_escape_string($_POST['name']);
                if($id&&$post)
                        {
                         $date=date('d:m:Y h:i:sa', (time()));
                        $q=mysql_query("INSERT INTO dis_posts (id,name,post,date) VALUE('$id','$name','$post','$date')");
		$registered = mysql_affected_rows();
		if ($registered==1){echo"posted";}else{echo"fail";}
                        }
}
?>
<?php 
if(isset($_POST['reptext']))
   {  
   		
   		include("include/connection.php");
                $post=mysql_real_escape_string($_POST['reptext']);
                $post = preg_replace('#[^a-z0-9/~!@$%^)(=[]/?><,._ /*/\/]#i','', $post);
                $post = str_replace("<", "&lt;", $post);
                $post = str_replace(">", "&gt;", $post);
                $id=mysql_real_escape_string($_POST['id']);
                $name=mysql_real_escape_string($_POST['name']);
                $postsno=mysql_real_escape_string($_POST['postno']);
                if($id&&$post)
                        {
                        
                         $date=date('d:m:Y h:i:sa', (time()));
                         include("include/connection.php");
                        $q=mysql_query("INSERT INTO dis_rep (id,name,postno,reply,date) VALUE('$id','$name','$postsno','$post','$date')");
		$registered = mysql_affected_rows();
		if ($registered==1){echo"posted";}else{echo"fail";}
                        }
}
?>
<?php 
if(isset($_POST['depost']))
   {  
   		
   		include("include/connection.php");
                $sno=mysql_real_escape_string($_POST['depost']);
                if($sno)
                        {
                        
                         $date=date('d:m:Y h:i:sa', (time()));
                         include("include/connection.php");
                         $b=mysql_query("DELETE FROM dis_rep WHERE postno='$sno'");
		$registered = mysql_affected_rows();
		if ($registered==1){
		        $b=mysql_query("DELETE FROM dis_posts WHERE sno='$sno'");
		                $reg = mysql_affected_rows();
		                if ($reg==1){echo"del";}else{echo"fail1";}
		
		
		}else{$b=mysql_query("DELETE FROM dis_posts WHERE sno='$sno'");
		                $reg = mysql_affected_rows();
		                if ($reg==1){echo"del";}else{echo"fail2";}}
                        }
} ?>
<?php
if(isset($_POST['derep']))
   {  
   		
   		include("include/connection.php");
                $sno=mysql_real_escape_string($_POST['derep']);
                if($sno)
                        {
                        
                         $date=date('d:m:Y h:i:sa', (time()));
                         include("include/connection.php");
                         $b=mysql_query("DELETE FROM dis_rep WHERE sno='$sno'");
		$registered = mysql_affected_rows();
		
		                if ($registered==1){echo"del";}else{echo"fail2";}}
                        }

?>
<?php 
if(isset($_POST['loginid']))
   { 
   		include("include/connection.php");
                $id = mysql_real_escape_string($_POST['loginid']);
                $id = preg_replace('#[^a-z0-9/~!@$%^)(=[]/?><,._ +/*/\/]#i','', $id);
                $id = str_replace("<", "&lt;", $id);
                $id = str_replace(">", "&gt;", $id);
                $pass=mysql_real_escape_string($_POST['pass']);
                if($id&&$pass)
                        {
                         $query = mysql_query("SELECT * FROM users where username='$id'  && password ='$pass'");
                        $numows = mysql_num_rows($query);
                                if($numows!=0){
                                     while($row = mysql_fetch_assoc($query)){
                                      $dbid= $row['username'];
	                             $dbpassword = $row['password'];
	                             
	                             }
	                             $_SESSION['id']=$dbid;
	                             $_SESSION['name'] = $row['stu_name']; 
	                             $ip = $_SERVER['REMOTE_ADDR'];
	                             $_SESSION['start'] =  date( (time() +16200));
                                                $a=mysql_query("UPDATE users SET ip='$ip' status='1' WHERE username='$id' ");
		                                $_SESSION['start'] =  date( (time() +16200)); // Taking now logged in time.
		                                // Ending a session in 30 minutes from the starting time.
		                                $_SESSION['expire'] = $_SESSION['start'] + (60);
		                                setcookie("id", $dbid, strtotime( '+20 hour' ), "/", "", "", TRUE);
                                                echo"ok"; 	
                                                 }
                                else  { echo"login_failedntreg"; }
                        }
}
?>