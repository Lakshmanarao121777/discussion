<!DOCTYPE html>
<?php session_start();?>
<html>
	<?php include("include/heading.php"); ?>


            <div class="page-inner" id="page">

	   	<style>   
.cont1{width:90%;border:1px solid black;position:relative;float:left;margin:20px 5% 30px 5%;padding:10px 10px 0 20px ;font-size:16px;color:rgba(0,40,20,0.7);line-height:2;}       
img{float:left;}i{color:green;}i::first-letter{text-transform:lowercase;}{color:green;}y{color:red}
.fields{font-size:15px;line-height:2;}
.valu{float:left;text-align:left;color:blue;padding:10px;margin:30px 0 0 80px;}
.inp{font-size:15px;text-align:left;padding-left:10px;text-decoration:underline;color:teal;} 
.postbox{width:100%;margin:10px 0 0 0%;border:1px solid gray;padding:10px;min-height:68px;line-height:1.3;letter-spacing:1.2px;}
.replybox{width:90%;margin:10px 0 0 0%;border:1px solid gray;padding:10px;min-height:68px;line-height:1.3;margin:1px 0 0 97px;}
.head{font-size:14px;color:rgba(0,0,200,0.7);}
.date{text-align:right;float:right;font-size:13px;color:red;margin-top:-1%;}
.post{font-size:19px;}
textarea{min-width:80%; padding:3px 0 0 10px;line-height:1.4;min-height:100px;}
#replytext{min-width:100%; padding:3px 0 0 10px;line-height:1.4;min-height:10px;}                            
  </style>                                          
                                                

<div class="cont1">
	<?php if($_SESSION){ ?>
	       <?php
 		include("include/connection.php");
                $qui2=mysql_query("select * from users where username='$_SESSION[id]'");
                $numi2 = mysql_num_rows($qui2); if($numi2!=0){
	                while($rowi2 = mysql_fetch_assoc($qui2)){ 
                  	$img2=$rowi2['username'].".jpg";$names=$rowi2['stu_name'];$cls=$rowi2['country'];}  }
                   	include("include/connection.php");
                $qui2=mysql_query("select * from faculty where username='$_SESSION[id]'");
                $numi2 = mysql_num_rows($qui2); if($numi2!=0){
	                while($rowi2 = mysql_fetch_assoc($qui2)){ 
                  	$img2=$rowi2['username'].".jpg"; $names=$rowi2['faculty_name'];$cls=$rowi2['faculty_name'];}  }	?>
	                           
	<form id="form_id" method="post" name="myform" >
                        <input type="hidden" id="idn" value="<?php echo $_SESSION['id'];?>">
                        <input type="hidden" id="name" value="<?php echo $names;?>">
                        
                        
                        <textarea placeholder="Please Type your answer here" required id="posttext"></textarea> 
                        <div id="bb"></div> 
                       <center> <input type="button" value="Publish" id="submit" onclick="postpost()" class="btn btn-primary"/>
                        <input type="reset" value="Reset" class="btn btn-primary"/></center></br>
        </form>     
	<?php } ?>     
	 <?php   include("include/connection.php");
$qu1=mysql_query("SELECT * FROM dis_posts ORDER BY sno DESC limit 0,15");
$num1 = mysql_num_rows($qu1);
if($num1!='0'){ 

	while($row1 = mysql_fetch_assoc($qu1)){
	$postid=$row1['sno'];   	$id = $row1['id'];
	$name = $row1['name'];  	$class = $row1['class'];
	$post = $row1['post'];  	$post = nl2br($post); 
	$post = str_replace("&amp;","&",$post); 	$post = stripslashes($post); 	$date=$row1['date'];  

                include("include/connection.php");
                $qui1=mysql_query("select * from users where username='$id'");
                $numi1 = mysql_num_rows($qui1);if($numi1 !=0){
	                while($rowi1 = mysql_fetch_assoc($qui1)){ 
                  $img1=$rowi1['username'].".jpg";}}
                  else{       include("include/connection.php");
                              $qui1=mysql_query("select * from faculty where username='$id'");
                              $numi1 = mysql_num_rows($qui1);
	                      while($rowi1 = mysql_fetch_assoc($qui1)){ 
                              $img1=$rowi1['username'].".jpg";}}
  
	echo" <div class='postbox'><div class='head'>"; ?><img src="./stu_imgs/<?php echo$img1; ?>" style='width:48px;height:48px;padding:0px 5px;border-radius:1px;'>
	<?php  echo" Posted by <i>$name</i> ( <y>$id</y> ) at <bdo dir='ltr'>$date</bdo></br></div>"; 
	if($_SESSION){if($_SESSION['id']=="r121777"||$id==$_SESSION['id']||$_SESSION['id']=='R121777'||$_SESSION['id']=='Admin'||$_SESSION['id']=='admin')  { ?>
	
	 
	     
	<form id="form_id1" method="post" name="notice">
	 <input type="hidden" id="<?php echo"str".$postid; ?>" value="<?php echo $postid; ?>">                
         <input type="button"value="Delete" id="noticedel" onclick="delpost('<?php echo $postid; ?>')"class="btn-primary"> 
	     </form>
	     
	<?php } }
 echo" $post</br><!--<div class='date'>$date</div>--></div>"; ?>

	 	 <?php   include("include/connection.php");
$qu2=mysql_query("SELECT * FROM dis_rep WHERE postno = $postid ORDER BY sno DESC limit 0,7");
$num2 = mysql_num_rows($qu2);
if($num2!='0'){ 

	while($row2 = mysql_fetch_assoc($qu2)){
	$id2 = $row2['id'];$sno2 = $row2['sno'];
	$post2 = $row2['reply']; 
	$post2 = nl2br($post2); 
	$post2 = str_replace("&amp;","&",$post2); 
	$post2 = stripslashes($post2); 
	$date2=$row2['date'];
        $author2=$row2['id']; 

                include("include/connection.php");
                $qui2=mysql_query("select * from users where username='$author2'");
                $numi2 = mysql_num_rows($qui2); if($numi2!=0){
	                while($rowi2 = mysql_fetch_assoc($qui2)){ 
                  $img2=$rowi2['username'].".jpg";$name2=$rowi2['stu_name'];}  }
               else{       include("include/connection.php");
                $qui2=mysql_query("select * from faculty where username='$author2'");
                $numi2 = mysql_num_rows($qui2);
	                while($rowi2 = mysql_fetch_assoc($qui2)){ 
                  $img2=$rowi2['username'].".jpg";$name2=$rowi2['faculty_name'];}}
                  echo" <div class='replybox'><div class='head'>"; ?><img src="./stu_imgs/<?php echo$img2; ?>" style='width:48px;height:48px;padding:0px 5px;'><?php echo"Replyed by <i>$name2</i> ( <y>$id2</y> ) at <bdo dir='ltr'>$date2</bdo></br></div>";
				  
	if($_SESSION){if($_SESSION['id']=="r121777"||$id==$_SESSION['id']||$_SESSION['id']=='R121777'||$_SESSION['id']=='Admin'||$_SESSION['id']=='admin')  { ?>
	
	 
	     
	<form id="form_id1" method="post" name="notice">
	 <input type="hidden" id="<?php echo"str".$sno2; ?>" value="<?php echo $sno2; ?>">                
         <input type="button"value="Delete" id="noticedel" onclick="delrep('<?php echo $sno2; ?>')"class="btn-primary"> 
	     </form>
	     
	<?php } }
	echo" $post2</br><!--<div class='date'>$date2</div>--></div>";
	
	
	
	
	
} }  ?>
                	
					<?php  if($_SESSION){
                include("include/connection.php");
                $qui2=mysql_query("select * from users where username='$_SESSION[id]'");
                $numi2 = mysql_num_rows($qui2); if($numi2!=0){
	        while($rowi2 = mysql_fetch_assoc($qui2)){ 
                $img2=$rowi2['username'].".jpg";$names=$rowi2['stu_name'];$cls=$rowi2['country'];}  }
                else {include("include/connection.php");
                $qui2=mysql_query("select * from faculty where username='$_SESSION[id]'");
                $numi2 = mysql_num_rows($qui2); if($numi2!=0){
	        while($rowi2 = mysql_fetch_assoc($qui2)){ 
                $img2=$rowi2['username'].".jpg"; $names=$rowi2['faculty_name'];$cls=$rowi2['faculty_name'];}  }}
	?>
	
	 
	   
	 <form id="form_id1" method="post" name="notice">
	 <input type="hidden" id="idnr" value="<?php echo $_SESSION['id'];?>">
	 <input type="hidden" id="namer" value="<?php echo $names;?>">
	 <input type="hidden" id="clsr" value="<?php echo $class;?>">
	 <input type="hidden" id="<?php echo"str".$postid; ?>" value="<?php echo $postid; ?>">
	 <textarea id="<?php echo$postid."reptext"; ?>" class="replytext" placeholder="Post a reply here" required></textarea>  
	 <div id="bbR"></div>                 
         <input type="button"value="Reply" class="btn btn-primary" id="noticedel" onclick="reppost('<?php echo $postid; ?>')"class="btn"> 
	     </form>           

<?php	 } } } ?>                        	

	</br>	
	</div>	
</br>

                                            </div>
											<div class="footer" id="footer" style="display:block;">&copy from 2016, D-FORUM, RGUKT, R.K.Valley. <br></br></div>
                                        </div>

                

        <!--<script type="text/javascript" src="assets_new/plugins/flexisel/js/jquery.flexisel.js"></script>-->
    </body>
<script type="text/javascript">
function ajaxObj(meth, url){
	var x= new XMLHttpRequest();
	x.open(meth,url,true);
	x.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	return x;	
}
function ajaxReturn(x){
	if(x.readyState == 4 && x.status == 200){
		return true;
	}
}
function _(x){
	return document.getElementById(x);
}
function toggleElement(x){ 
	var x = _(x);
	if(x.style.display == 'block'){ 
		x.style.display = 'none'; 
		}
	else{ 
		x.style.display = 'block'; 
		} 
}

function postpost(){
var idn  = _("idn").value;
var name = _("name").value;
var posts  = _("posttext").value;
                        if ( idn!= "" && name != "" && posts != ""){ 
			var ajax = ajaxObj("POST","hub.php");			
			ajax.onreadystatechange = function() {
			//alert(idn+cls+name +'\n'+ posts);
			    if (ajax.readyState==3)
                                { _("bb").innerHTML='Loading please wait.....';}
			    if (ajax.readyState==4 && ajax.status==200)
                                   { 
                                    if(ajaxReturn(ajax) == true) {
				//alert(ajax.responseText);
				        if(ajax.responseText == "posted"){  window.location.href = "index.php"; }
				        else  {window.location.href = "index.php"; _("bb").innerHTML = "Posting Failed Try again....."; }
				        }  }}                              
                        ajax.send("id="+idn+"&name="+name+"&posttext="+posts);
                        }
}
function reppost(a){ 
var idnr  = _("idnr").value;
var namer = _("namer").value;
//var psno = _("postsno").value;
var reps  = _(a+"reptext").value;
                        if ( idnr!= ""&& namer != "" && reps != "" && a !=""){ 
			var ajax = ajaxObj("POST","hub.php");			
			ajax.onreadystatechange = function() {
			
			    if (ajax.readyState==3)
                                { _("bbR").innerHTML='Loading please wait.....';}
			    if (ajax.readyState==4 && ajax.status==200)
                                   { 
                                    if(ajaxReturn(ajax) == true) {
				//alert(ajax.responseText);
				        if(ajax.responseText == "posted"){  window.location.href = "index.php"; }
				        else  { window.location.href = "index.php"; }
				        }  }}                              
                        ajax.send("id="+idnr+"&name="+namer+"&reptext="+reps+"&postno="+a);
                        }
}
function delpost(a){ 

                        if ( a !=""){ 
			var ajax = ajaxObj("POST","hub.php");			
			ajax.onreadystatechange = function() {
			
			    if (ajax.readyState==3)
                                { _("bbR").innerHTML='Loading please wait.....';}
			    if (ajax.readyState==4 && ajax.status==200)
                                   { 
                                    if(ajaxReturn(ajax) == true) {
				//alert(ajax.responseText);
				        if(ajax.responseText == "del"){  window.location.href = "index.php"; }
				        else  { window.location.href = "index.php"; }
				        }  }}                              
                        ajax.send("depost="+a);
                        }
}
function delrep(a){ 

                        if ( a !=""){ 
			var ajax = ajaxObj("POST","hub.php");			
			ajax.onreadystatechange = function() {
			
			    if (ajax.readyState==3)
                                { _("bbR").innerHTML='Loading please wait.....';}
			    if (ajax.readyState==4 && ajax.status==200)
                                   { 
                                    if(ajaxReturn(ajax) == true) {
				//alert(ajax.responseText);
				        if(ajax.responseText == "del"){  window.location.href = "index.php"; }
				        else  { window.location.href = "index.php"; }
				        }  }}                              
                        ajax.send("derep="+a);
                        }
}
function validatestu(){
var idn  = _("username").value;
var passwd = _("password").value;
                        if ( idn!= "" && passwd != "" ){ 
			var ajax = ajaxObj("POST","hub.php");			
			ajax.onreadystatechange = function() {
			//alert(idn+cls+name +'\n'+ posts);
			    if (ajax.readyState==3)  { }
			    if (ajax.readyState==4 && ajax.status==200)
                                   { 
                                    if(ajaxReturn(ajax) == true) {
					//alert(ajax.responseText);
				        if(ajax.responseText == "posted"){  window.location.href = "index.php"; }
				        else  {window.location.href = "index.php"; }
				        }  }}                              
                        ajax.send("loginid="+idn+"&pass="+passwd);
                        }
}


</script>

</html>
